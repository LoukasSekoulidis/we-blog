const config = {
    API_URL: 'https://127.0.0.1/'
}

export default config;